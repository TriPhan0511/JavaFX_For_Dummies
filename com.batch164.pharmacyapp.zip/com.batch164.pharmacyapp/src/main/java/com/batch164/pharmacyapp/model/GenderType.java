package com.batch164.pharmacyapp.model;

public enum GenderType
{
  MALE, FEMALE
}
