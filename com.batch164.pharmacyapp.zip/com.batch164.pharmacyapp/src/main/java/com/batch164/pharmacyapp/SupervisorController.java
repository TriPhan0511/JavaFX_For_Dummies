package com.batch164.pharmacyapp;

public class SupervisorController
{
}
