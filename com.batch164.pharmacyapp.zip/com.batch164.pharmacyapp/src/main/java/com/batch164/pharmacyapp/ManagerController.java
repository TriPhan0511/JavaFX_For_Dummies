package com.batch164.pharmacyapp;

public class ManagerController
{
}
